#!/usr/bin/env python3
"""
attention_profile.py — Class-conditional channel attention weight profiles.

Implements the interpretability analysis described in Section 9.5 of the paper
(Table 12):

  For each disaster class c ∈ {DF, GC, SEQ, HH, ND}, compute the
  class-conditional mean attention profile:

        ᾱ_c = (1/|T_c|) Σ_{x ∈ T_c} α(x)

  where T_c is the fixed test set for class c and α(x) ∈ [0,1]^256 is the
  sigmoid channel-attention mask produced by the MS Fusion model for sample x.

  Channels are classified as:
    Amplified  : ᾱ_{c,k} > 0.7
    Suppressed : ᾱ_{c,k} < 0.3
    Neutral    : otherwise

  The top-K most class-selective channels are identified using the contrast
  score  δ_k = max_c ᾱ_{c,k} − min_c ᾱ_{c,k}.

Usage:
    # Compute profiles for the representative run (seed 3)
    python attention_profile.py \\
        --checkpoint ./output/ms_fusion/seed_3/best.pt \\
        --data_root  ./data \\
        --output_dir ./output/ms_fusion/seed_3

    # Load pre-saved alpha arrays instead of re-running inference
    python attention_profile.py \\
        --npy_path ./output/ms_fusion/seed_3/attention_profiles.npy \\
        --labels_npy ./output/ms_fusion/seed_3/test_labels.npy \\
        --output_dir ./output/ms_fusion/seed_3

Outputs:
    attention_profiles.npy      (N_test, 256)  — per-sample alpha vectors
    test_labels.npy             (N_test,)       — ground-truth labels
    class_profiles.json         per-class mean alpha vectors + statistics
    attention_profile_table.csv Table 12 (Amplified / Suppressed / Neutral %)

Cite:
    Bouabid, M., & Farah, M. (2025). MultiSense: A Knowledge-Guided Multimodal
    Benchmark and Attention Fusion Framework for Multi-Disaster Detection in
    Smart Cities. The Visual Computer. https://github.com/Marwen200/Multisense
"""

import os
import json
import argparse
import csv

import numpy as np
import torch
from torch.utils.data import DataLoader

from multisense import (
    MSFusionModel, MultiSenseDataset,
    CLASS_NAMES, NUM_CLASSES,
)

# Thresholds for channel classification (Section 9.5)
AMPLIFIED_THRESH  = 0.7
SUPPRESSED_THRESH = 0.3
TOP_K_SELECTIVE   = 32   # number of most class-selective channels to report


# ══════════════════════════════════════════════════════════════════════════════
# Inference — collect alpha vectors from the test set
# ══════════════════════════════════════════════════════════════════════════════

def collect_alphas(
    checkpoint:  str,
    data_root:   str,
    pairs_csv:   str | None,
    output_dir:  str,
    device:      str,
    num_workers: int,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Run a forward pass on the fixed imbalanced test set and collect:
      - alpha_matrix  (N, 256): channel attention weights per sample
      - labels        (N,):     ground-truth class indices

    The arrays are saved as .npy files for fast reloading.
    """
    # ── Load model ────────────────────────────────────────────────────────────
    model = MSFusionModel(save_dir=output_dir, num_class=NUM_CLASSES)
    model.load(checkpoint)
    model = model.to(device)
    model.eval()
    print(f"  Loaded checkpoint: {checkpoint}")

    # ── Test set (fixed imbalanced pairs) ─────────────────────────────────────
    test_set    = MultiSenseDataset(data_root, "test",
                                    pairs_csv=pairs_csv, augment=False)
    test_loader = DataLoader(test_set, batch_size=64,
                             shuffle=False, num_workers=num_workers)

    all_alphas: list[np.ndarray] = []
    all_labels: list[int]        = []

    with torch.no_grad():
        for batch in test_loader:
            sat    = batch["satellite"].to(device)
            uav    = batch["uav"].to(device)
            labels = batch["label"].cpu().tolist()

            _, alpha = model((sat, uav))    # alpha: (B, 256)
            all_alphas.append(alpha.cpu().numpy())
            all_labels.extend(labels)

    alpha_matrix = np.vstack(all_alphas)   # (N, 256)
    label_array  = np.array(all_labels)    # (N,)

    # ── Save for future reuse ─────────────────────────────────────────────────
    np.save(os.path.join(output_dir, "attention_profiles.npy"), alpha_matrix)
    np.save(os.path.join(output_dir, "test_labels.npy"),        label_array)
    print(f"  Saved alpha matrix {alpha_matrix.shape} → attention_profiles.npy")

    return alpha_matrix, label_array


# ══════════════════════════════════════════════════════════════════════════════
# Profile computation and reporting
# ══════════════════════════════════════════════════════════════════════════════

def compute_class_profiles(
    alpha_matrix: np.ndarray,   # (N, 256)
    labels:       np.ndarray,   # (N,)
) -> dict[str, dict]:
    """
    Compute class-conditional mean attention profile ᾱ_c for each class.

    Returns a dict mapping class_name → {
        'mean_alpha':   list of 256 float values,
        'amplified_pct': float,
        'suppressed_pct': float,
        'neutral_pct':   float,
    }
    """
    profiles = {}
    for cls_idx, cls_name in enumerate(CLASS_NAMES):
        mask    = labels == cls_idx
        n_cls   = mask.sum()
        if n_cls == 0:
            print(f"  [WARN] No test samples for class '{cls_name}'")
            continue

        mean_alpha = alpha_matrix[mask].mean(axis=0)   # (256,)

        amplified  = (mean_alpha > AMPLIFIED_THRESH).sum()
        suppressed = (mean_alpha < SUPPRESSED_THRESH).sum()
        neutral    = len(mean_alpha) - amplified - suppressed

        profiles[cls_name] = {
            "n_samples":      int(n_cls),
            "mean_alpha":     mean_alpha.tolist(),
            "amplified_pct":  round(float(amplified  / len(mean_alpha) * 100), 1),
            "suppressed_pct": round(float(suppressed / len(mean_alpha) * 100), 1),
            "neutral_pct":    round(float(neutral    / len(mean_alpha) * 100), 1),
        }

    return profiles


def identify_selective_channels(
    profiles: dict[str, dict],
    top_k:    int = TOP_K_SELECTIVE,
) -> list[dict]:
    """
    Rank channels by contrast score  δ_k = max_c ᾱ_{c,k} − min_c ᾱ_{c,k}.

    Returns the top-K most class-selective channels as a list of dicts:
    {channel_index, delta, per_class_alpha}.
    """
    n_channels  = len(next(iter(profiles.values()))["mean_alpha"])
    class_means = np.array([profiles[c]["mean_alpha"] for c in CLASS_NAMES
                             if c in profiles])          # (C, 256)
    delta       = class_means.max(axis=0) - class_means.min(axis=0)  # (256,)
    top_indices = np.argsort(delta)[::-1][:top_k]

    selective = []
    for k in top_indices:
        selective.append({
            "channel":         int(k),
            "delta":           round(float(delta[k]), 4),
            "per_class_alpha": {
                cls: round(float(class_means[i, k]), 4)
                for i, cls in enumerate(
                    [c for c in CLASS_NAMES if c in profiles]
                )
            },
        })
    return selective


def print_table12(profiles: dict[str, dict]) -> None:
    """Print Table 12 of the paper: Amplified / Suppressed / Neutral per class."""
    header = (f"\n{'Class':<25} {'Amplified (%)':>14} "
              f"{'Suppressed (%)':>15} {'Neutral (%)':>12}")
    sep    = "─" * len(header)
    print(header)
    print(sep)
    for cls_name in CLASS_NAMES:
        if cls_name not in profiles:
            continue
        s = profiles[cls_name]
        print(f"{cls_name:<25} {s['amplified_pct']:>14.1f} "
              f"{s['suppressed_pct']:>15.1f} {s['neutral_pct']:>12.1f}")
    print()


def save_table_csv(profiles: dict[str, dict], output_dir: str) -> None:
    """Save Table 12 as a CSV for inclusion in the paper or further analysis."""
    csv_path = os.path.join(output_dir, "attention_profile_table.csv")
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(
            f, fieldnames=["class", "n_samples",
                           "amplified_pct", "suppressed_pct", "neutral_pct"]
        )
        writer.writeheader()
        for cls_name in CLASS_NAMES:
            if cls_name not in profiles:
                continue
            s = profiles[cls_name]
            writer.writerow({
                "class":           cls_name,
                "n_samples":       s["n_samples"],
                "amplified_pct":   s["amplified_pct"],
                "suppressed_pct":  s["suppressed_pct"],
                "neutral_pct":     s["neutral_pct"],
            })
    print(f"Table 12 CSV → {csv_path}")


# ══════════════════════════════════════════════════════════════════════════════
# Analytical predictions (Section 9.5 of the paper)
# ══════════════════════════════════════════════════════════════════════════════

def verify_predictions(profiles: dict[str, dict]) -> None:
    """
    Test the three theoretically motivated predictions from Section 9.5
    against the computed profiles:

    P1: No Damage should have the highest suppression rate and the lowest
        amplification (consistent with the 4.28 pp ablation drop).

    P2: Derna Flood and Hurricane Harvey should have the two highest
        amplification rates (shared water-coverage channels).

    P3: Gaza Conflict and Syria-Turkey EQ should occupy structurally
        contrasting positions in suppression space.
    """
    print("─" * 60)
    print("  Analytical prediction checks (Section 9.5):")

    if "no_damage" in profiles:
        nd = profiles["no_damage"]
        others_sup = [profiles[c]["suppressed_pct"] for c in CLASS_NAMES
                      if c != "no_damage" and c in profiles]
        p1_ok = (nd["suppressed_pct"] > max(others_sup)
                 and nd["amplified_pct"] < min(
                     profiles[c]["amplified_pct"] for c in CLASS_NAMES
                     if c != "no_damage" and c in profiles
                 ))
        print(f"  P1 (ND highest suppression): {'✓' if p1_ok else '✗'}  "
              f"ND suppressed={nd['suppressed_pct']:.1f}% "
              f"vs max_others={max(others_sup):.1f}%")

    flood_classes = [c for c in ["derna_flood", "hurricane_harvey"]
                     if c in profiles]
    other_classes = [c for c in CLASS_NAMES
                     if c not in flood_classes and c in profiles]
    if len(flood_classes) == 2 and other_classes:
        flood_amp  = [profiles[c]["amplified_pct"] for c in flood_classes]
        other_amp  = [profiles[c]["amplified_pct"] for c in other_classes]
        p2_ok      = min(flood_amp) > max(other_amp)
        print(f"  P2 (flood highest amplif.): {'✓' if p2_ok else '✗'}  "
              f"flood={flood_amp}  others={other_amp}")

    if "gaza_conflict" in profiles and "syria_turkey_eq" in profiles:
        gc_sup = profiles["gaza_conflict"]["suppressed_pct"]
        eq_sup = profiles["syria_turkey_eq"]["suppressed_pct"]
        gc_amp = profiles["gaza_conflict"]["amplified_pct"]
        eq_amp = profiles["syria_turkey_eq"]["amplified_pct"]
        p3_ok  = (gc_amp != eq_amp) or (gc_sup != eq_sup)
        print(f"  P3 (GC vs SEQ contrast):   {'✓' if p3_ok else '?'}  "
              f"GC amp={gc_amp:.1f}%/sup={gc_sup:.1f}%  "
              f"SEQ amp={eq_amp:.1f}%/sup={eq_sup:.1f}%")
    print("─" * 60)


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════

def main() -> None:
    p = argparse.ArgumentParser(
        description="Compute class-conditional attention profiles (Table 12)",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    # Inference mode: run from checkpoint
    p.add_argument("--checkpoint",  default=None,
                   help="Path to best.pt checkpoint of a trained MSFusionModel.")
    p.add_argument("--data_root",   default="./data")
    p.add_argument("--pairs_csv",   default=None)
    # Load-from-npy mode: skip inference and load saved arrays
    p.add_argument("--npy_path",    default=None,
                   help="Path to attention_profiles.npy (skip inference).")
    p.add_argument("--labels_npy",  default=None,
                   help="Path to test_labels.npy (required with --npy_path).")
    # Common
    p.add_argument("--output_dir",  default="./output/attention")
    p.add_argument("--top_k",       type=int, default=TOP_K_SELECTIVE,
                   help="Number of most class-selective channels to report.")
    p.add_argument("--device",      default="cuda" if torch.cuda.is_available()
                                            else "cpu")
    p.add_argument("--num_workers", type=int, default=2)
    args = p.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    # ── Step 1: Collect alpha vectors ──────────────────────────────────────────
    if args.npy_path is not None:
        print("Loading pre-saved alpha vectors …")
        alpha_matrix = np.load(args.npy_path)
        label_array  = np.load(args.labels_npy)
    elif args.checkpoint is not None:
        print("Running test-set inference to collect alpha vectors …")
        alpha_matrix, label_array = collect_alphas(
            checkpoint=args.checkpoint,
            data_root=args.data_root,
            pairs_csv=args.pairs_csv,
            output_dir=args.output_dir,
            device=args.device,
            num_workers=args.num_workers,
        )
    else:
        raise ValueError("Supply either --checkpoint or --npy_path")

    print(f"  Alpha matrix: {alpha_matrix.shape}  "
          f"(thresholds: amp>{AMPLIFIED_THRESH}, sup<{SUPPRESSED_THRESH})")

    # ── Step 2: Compute per-class profiles ─────────────────────────────────────
    profiles = compute_class_profiles(alpha_matrix, label_array)

    # ── Step 3: Print Table 12 ─────────────────────────────────────────────────
    print("\n  Table 12 — Class-Conditional Attention Profile Statistics")
    print_table12(profiles)

    # ── Step 4: Identify most class-selective channels ─────────────────────────
    selective = identify_selective_channels(profiles, top_k=args.top_k)
    print(f"  Top-{args.top_k} class-selective channels (by contrast score δ_k):")
    for entry in selective[:5]:   # show top 5 in console
        print(f"    ch={entry['channel']:>3}  δ={entry['delta']:.4f}  "
              f"{entry['per_class_alpha']}")

    # ── Step 5: Verify theoretical predictions ─────────────────────────────────
    verify_predictions(profiles)

    # ── Step 6: Save all outputs ───────────────────────────────────────────────
    json_path = os.path.join(args.output_dir, "class_profiles.json")
    with open(json_path, "w") as f:
        json.dump({"profiles": profiles, "selective_channels": selective}, f, indent=2)
    print(f"  Class profiles  → {json_path}")

    save_table_csv(profiles, args.output_dir)
    print("\n✓  Attention profile analysis complete.")


if __name__ == "__main__":
    main()
