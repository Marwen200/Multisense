#!/usr/bin/env python3
"""
generate_splits.py — Stratified group split + fixed test-set pair generation.

Implements the exact dataset construction protocol described in Section 4.4
of the paper:

  1. Stratified group split (70 / 15 / 15) with random.seed(42), ensuring
     no image from the same source video or satellite scene appears in more
     than one partition.

  2. Fixed test-set pairs:
       • Imbalanced: all available test-split satellite tiles paired with a
         UAV frame from the same class (numpy.random.seed(42), one application
         per class).  Total: up to 3812 pairs.
       • Balanced:   600 pairs per class (downsampled from imbalanced set,
         numpy.random.seed(42), one application per class).

  3. Outputs:
       <output_dir>/train_val_test_split.json  — per-class file lists
       <output_dir>/imbalanced_test_pairs.json — 3812 fixed pairs
       <output_dir>/balanced_test_pairs.json   — 3000 fixed pairs (600 × 5)
       <output_dir>/pairs_all.csv             — full CSV with all splits

Usage:
    python generate_splits.py --data_root ./data --output_dir ./data/splits

Cite:
    Bouabid, M., & Farah, M. (2025). MultiSense: A Knowledge-Guided Multimodal
    Benchmark and Attention Fusion Framework for Multi-Disaster Detection in
    Smart Cities. The Visual Computer. https://github.com/Marwen200/Multisense
"""

import os
import json
import csv
import glob
import random
import argparse
import numpy as np


# Five disaster classes — order defines integer labels 0–4
CLASS_NAMES = [
    "derna_flood",
    "gaza_conflict",
    "syria_turkey_eq",
    "hurricane_harvey",
    "no_damage",
]

# 70 / 15 / 15 train / val / test fractions
SPLIT_RATIOS = (0.70, 0.15, 0.15)
BALANCED_PER_CLASS = 600   # pairs per class in the balanced test set


def collect_images(root: str) -> list[str]:
    """Return sorted list of all image files under a directory."""
    exts = ("*.jpg", "*.jpeg", "*.png", "*.tif", "*.tiff")
    files = []
    for ext in exts:
        files.extend(glob.glob(os.path.join(root, "**", ext), recursive=True))
    return sorted(files)


def stratified_group_split(
    sat_files: list[str],
    seed: int = 42,
) -> tuple[list[str], list[str], list[str]]:
    """
    Split satellite files into train / val / test using stratified random
    assignment with the given seed.

    The paper's protocol states that all tiles from the same PlanetScope scene
    share a scene-ID prefix in the filename (or parent directory).  If your
    filenames encode scene IDs, group by that prefix here.  As a conservative
    default, each file is treated as its own group (file-level split).

    Args:
        sat_files: Sorted list of satellite image paths for one class.
        seed:      RNG seed (42 throughout the paper).

    Returns:
        (train_files, val_files, test_files)
    """
    rng   = random.Random(seed)
    files = list(sat_files)
    rng.shuffle(files)

    n     = len(files)
    n_val  = max(1, round(n * SPLIT_RATIOS[1]))
    n_test = max(1, round(n * SPLIT_RATIOS[2]))
    n_train = n - n_val - n_test

    train = files[:n_train]
    val   = files[n_train: n_train + n_val]
    test  = files[n_train + n_val:]
    return train, val, test


def make_fixed_pairs(
    sat_files:  list[str],
    uav_files:  list[str],
    label:      int,
    split:      str,
    n_balanced: int = BALANCED_PER_CLASS,
    seed:       int = 42,
) -> tuple[list[dict], list[dict]]:
    """
    Create fixed satellite–UAV pairs for val / test splits.

    For each satellite tile, a UAV frame is selected uniformly at random
    from the same class pool (with replacement) using numpy.random.seed(42)
    — one seed application per class, as stated in Section 4.4.

    Args:
        sat_files:  Satellite image paths for this class and split.
        uav_files:  UAV frame paths for this class and split.
        label:      Integer class label.
        split:      'val' or 'test'.
        n_balanced: Number of pairs for the balanced subset.
        seed:       RNG seed.

    Returns:
        (imbalanced_pairs, balanced_pairs) — both are lists of dicts with keys
        {satellite_path, uav_path, label, split}.
    """
    rng    = np.random.default_rng(seed=seed)
    n_sat  = len(sat_files)
    n_uav  = len(uav_files)

    # Assign one UAV frame to every satellite tile (with replacement)
    uav_indices = rng.choice(n_uav, size=n_sat, replace=True)
    imbalanced  = [
        {"satellite_path": sat_files[i],
         "uav_path":       uav_files[uav_indices[i]],
         "label":          label,
         "split":          split}
        for i in range(n_sat)
    ]

    # Balanced: downsample to n_balanced pairs (or all if fewer available)
    if n_sat <= n_balanced:
        balanced = list(imbalanced)
    else:
        idx      = rng.choice(n_sat, size=n_balanced, replace=False)
        balanced = [imbalanced[i] for i in sorted(idx)]

    return imbalanced, balanced


def main() -> None:
    p = argparse.ArgumentParser(
        description="Generate MultiSense stratified splits and fixed test-set pairs",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--data_root",  required=True,
                   help="Root containing satellite/ and uav/ sub-directories.")
    p.add_argument("--output_dir", default="./splits",
                   help="Directory to write JSON / CSV split files.")
    p.add_argument("--seed",       type=int, default=42,
                   help="Random seed for split and pairing (42 throughout the paper).")
    p.add_argument("--balanced_per_class", type=int, default=BALANCED_PER_CLASS,
                   help="Pairs per class in the balanced test set (600 in the paper).")
    args = p.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    sat_root = os.path.join(args.data_root, "satellite")
    uav_root = os.path.join(args.data_root, "uav")

    split_registry   = {}        # {class_name: {train/val/test: [paths]}}
    all_imbalanced   = []
    all_balanced     = []
    all_train_pairs  = []
    all_val_pairs    = []

    print(f"Scanning data root: {args.data_root}")

    for label, class_name in enumerate(CLASS_NAMES):
        sat_dir = os.path.join(sat_root, class_name)
        uav_dir = os.path.join(uav_root, class_name)

        if not os.path.isdir(sat_dir):
            print(f"  [WARN] {sat_dir} not found — skipping class '{class_name}'")
            continue
        if not os.path.isdir(uav_dir):
            print(f"  [WARN] {uav_dir} not found — skipping class '{class_name}'")
            continue

        sat_files = collect_images(sat_dir)
        uav_files = collect_images(uav_dir)
        print(f"  {class_name}: {len(sat_files)} satellite tiles, "
              f"{len(uav_files)} UAV frames")

        if not sat_files or not uav_files:
            print(f"  [WARN] Empty directory for '{class_name}' — skipping")
            continue

        # ── 70/15/15 stratified split ─────────────────────────────────────
        train_sat, val_sat, test_sat = stratified_group_split(sat_files, args.seed)
        train_uav, val_uav, test_uav = stratified_group_split(uav_files, args.seed)

        split_registry[class_name] = {
            "label":      label,
            "train_sat":  train_sat,  "train_uav":  train_uav,
            "val_sat":    val_sat,    "val_uav":    val_uav,
            "test_sat":   test_sat,   "test_uav":   test_uav,
        }
        print(f"    Split: {len(train_sat)} / {len(val_sat)} / {len(test_sat)}")

        # ── Fixed val pairs ───────────────────────────────────────────────
        val_imb, val_bal = make_fixed_pairs(
            val_sat, val_uav, label, "val",
            n_balanced=args.balanced_per_class, seed=args.seed
        )
        all_val_pairs.extend(val_imb)

        # ── Fixed test pairs ──────────────────────────────────────────────
        test_imb, test_bal = make_fixed_pairs(
            test_sat, test_uav, label, "test",
            n_balanced=args.balanced_per_class, seed=args.seed
        )
        all_imbalanced.extend(test_imb)
        all_balanced.extend(test_bal)
        print(f"    Test pairs: {len(test_imb)} imbalanced, "
              f"{len(test_bal)} balanced")

        # ── Dynamic training pairs (stored as file lists; paired at runtime) ─
        for sat in train_sat:
            all_train_pairs.append({
                "satellite_path": sat,
                "uav_pool":       train_uav,   # pool for random selection
                "label":          label,
                "split":          "train",
            })

    # ── Write split registry ──────────────────────────────────────────────────
    registry_path = os.path.join(args.output_dir, "train_val_test_split.json")
    with open(registry_path, "w") as f:
        json.dump(split_registry, f, indent=2)
    print(f"\nSplit registry  → {registry_path}")

    # ── Write imbalanced test pairs ───────────────────────────────────────────
    imb_path = os.path.join(args.output_dir, "imbalanced_test_pairs.json")
    with open(imb_path, "w") as f:
        json.dump(all_imbalanced, f, indent=2)
    print(f"Imbalanced pairs → {imb_path}  ({len(all_imbalanced)} pairs)")

    # ── Write balanced test pairs ─────────────────────────────────────────────
    bal_path = os.path.join(args.output_dir, "balanced_test_pairs.json")
    with open(bal_path, "w") as f:
        json.dump(all_balanced, f, indent=2)
    print(f"Balanced pairs   → {bal_path}  ({len(all_balanced)} pairs)")

    # ── Write master CSV (all splits) ─────────────────────────────────────────
    csv_rows = []
    # Training rows (one per satellite tile; uav_pool not stored in CSV)
    for row in all_train_pairs:
        csv_rows.append({
            "satellite_path": row["satellite_path"],
            "uav_path":       "",   # chosen randomly at train time
            "label":          row["label"],
            "split":          "train",
        })
    # Val and test rows
    for row in all_val_pairs + all_imbalanced:
        csv_rows.append({
            "satellite_path": row["satellite_path"],
            "uav_path":       row["uav_path"],
            "label":          row["label"],
            "split":          row["split"],
        })

    csv_path = os.path.join(args.output_dir, "pairs_all.csv")
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(
            f, fieldnames=["satellite_path", "uav_path", "label", "split"]
        )
        writer.writeheader()
        writer.writerows(csv_rows)
    print(f"Master CSV       → {csv_path}  ({len(csv_rows)} rows)")

    print("\n✓  Split generation complete.")
    print(f"   Pass --pairs_csv {csv_path} to train.py / train_all.sh")
    print(f"   to use these fixed splits in all experiments.")


if __name__ == "__main__":
    main()
