#!/usr/bin/env python3
"""
loeo_eval.py — Leave-One-Event-Out (LOEO) generalisation experiment.

Implements Section 9.4 of the paper (Table 11):

  For each of the four disaster events:
    • Withholds the entire event from training AND validation.
    • Trains MS Fusion on the remaining three events.
    • Evaluates on the held-out event's test tiles.

  This is the definitive test of whether the model learns damage-specific
  features rather than event-region fingerprints.  An LOEO mean accuracy
  substantially above the 20% uniform-class random baseline confirms
  damage-feature learning.

Protocol (5 steps from Section 9.4):
  1. Each round withholds one of: Derna Flood, Gaza Conflict,
     Syria-Turkey EQ, or Hurricane Harvey.
  2. No Damage class retains only tiles from the three training events.
  3. Same SGD, LR, batch size, and early stopping as the main experiment.
  4. Evaluation on all available imbalanced test tiles of the held-out event.
  5. Results reported per held-out round and as mean across four rounds.

Usage:
    python loeo_eval.py --data_root ./data --output_dir ./output/loeo

    # Re-evaluate saved checkpoints (skip training):
    python loeo_eval.py --data_root ./data --output_dir ./output/loeo --eval_only

Outputs:
    output_dir/
      loeo_derna_flood/          — checkpoint + logs for each held-out round
      loeo_gaza_conflict/
      loeo_syria_turkey_eq/
      loeo_hurricane_harvey/
      loeo_results.json          — Table 11 numbers (acc, macro-F1 per round)
      loeo_results_table.csv     — Table 11 as CSV

Cite:
    Bouabid, M., & Farah, M. (2025). MultiSense: A Knowledge-Guided Multimodal
    Benchmark and Attention Fusion Framework for Multi-Disaster Detection in
    Smart Cities. The Visual Computer. https://github.com/Marwen200/Multisense
"""

import os
import json
import csv
import argparse
import random

import numpy as np
import torch
import torch.nn as nn
from torch import optim
from torch.utils.data import Dataset, DataLoader, Subset
from torchvision import transforms
from PIL import Image
from tqdm import tqdm

from multisense import (
    MSFusionModel, MultiSenseDataset,
    CLASS_NAMES, NUM_CLASSES,
    compute_metrics, print_metrics,
)

# Held-out events — No Damage is always shared; only disaster events are held out
HELD_OUT_EVENTS = [
    "derna_flood",
    "gaza_conflict",
    "syria_turkey_eq",
    "hurricane_harvey",
]


# ══════════════════════════════════════════════════════════════════════════════
# LOEO-filtered dataset wrapper
# ══════════════════════════════════════════════════════════════════════════════

class LOEODataset(Dataset):
    """
    Wraps MultiSenseDataset to exclude a specified held-out event from all
    splits, AND restricts the No Damage class to tiles from the three
    training events only.

    Args:
        base_dataset:  A fully initialised MultiSenseDataset.
        held_out:      Class name of the held-out event (e.g. 'derna_flood').
        held_out_only: If True, keep ONLY the held-out event (for eval).
    """

    def __init__(self, base_dataset: MultiSenseDataset,
                 held_out: str, held_out_only: bool = False):
        self.base        = base_dataset
        self.held_out    = held_out
        held_out_label   = CLASS_NAMES.index(held_out)
        nd_label         = CLASS_NAMES.index("no_damage")

        # Build filtered index list
        self.indices: list[int] = []
        for i, pair in enumerate(base_dataset.pairs):
            label = pair["label"]

            if held_out_only:
                # Evaluation split: keep only the held-out disaster class
                if label == held_out_label:
                    self.indices.append(i)
            else:
                # Training split: drop the held-out class entirely;
                # also drop No Damage entries that reference the held-out region.
                # (Since No Damage tiles are tied to specific geographic sites,
                # we conservatively drop all No Damage tiles that share path
                # patterns with the held-out event's satellite directory.)
                if label == held_out_label:
                    continue
                if label == nd_label:
                    path = pair["sat"].lower()
                    # Heuristic: skip ND tiles whose path contains the held-out
                    # event name pattern (e.g. 'derna' for derna_flood)
                    event_keyword = held_out.split("_")[0]
                    if event_keyword in path:
                        continue
                self.indices.append(i)

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, idx: int) -> dict:
        return self.base[self.indices[idx]]


# ══════════════════════════════════════════════════════════════════════════════
# Single LOEO round
# ══════════════════════════════════════════════════════════════════════════════

def run_loeo_round(
    held_out:    str,
    data_root:   str,
    output_dir:  str,
    pairs_csv:   str | None,
    device:      str,
    num_workers: int,
    max_epochs:  int,
    seed:        int,
    eval_only:   bool,
) -> dict:
    """
    Train MS Fusion on three events, evaluate on the held-out fourth.

    Returns metrics dict for the held-out event.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    run_dir = os.path.join(output_dir, f"loeo_{held_out}")
    os.makedirs(run_dir, exist_ok=True)
    print(f"\n  ── Held-out: {held_out.upper()} ──")

    # ── Build filtered datasets ────────────────────────────────────────────────
    raw_train = MultiSenseDataset(data_root, "train",
                                  pairs_csv=pairs_csv, augment=True)
    raw_val   = MultiSenseDataset(data_root, "val",
                                  pairs_csv=pairs_csv, augment=False)
    raw_test  = MultiSenseDataset(data_root, "test",
                                  pairs_csv=pairs_csv, augment=False)

    train_set    = LOEODataset(raw_train, held_out, held_out_only=False)
    val_set      = LOEODataset(raw_val,   held_out, held_out_only=False)
    held_out_set = LOEODataset(raw_test,  held_out, held_out_only=True)

    print(f"    Train: {len(train_set)} | Val: {len(val_set)} "
          f"| Test (held-out only): {len(held_out_set)}")

    train_loader = DataLoader(train_set, batch_size=16, shuffle=True,
                              num_workers=num_workers, pin_memory=True)
    val_loader   = DataLoader(val_set,   batch_size=32, shuffle=False,
                              num_workers=num_workers, pin_memory=True)
    test_loader  = DataLoader(held_out_set, batch_size=32, shuffle=False,
                              num_workers=num_workers, pin_memory=True)

    # ── Model ─────────────────────────────────────────────────────────────────
    model     = MSFusionModel(save_dir=run_dir, num_class=NUM_CLASSES).to(device)
    loss_fn   = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=2e-3, momentum=0.9)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, factor=0.1, patience=5, verbose=False
    )
    scaler    = (torch.cuda.amp.GradScaler()
                 if device != "cpu" else None)

    # ── Training with early stopping ──────────────────────────────────────────
    if not eval_only:
        best_val_loss  = float("inf")
        no_improve     = 0
        patience       = 10   # same as main experiment (Section 6.1)

        for epoch in range(max_epochs):
            model.train()
            for batch in tqdm(train_loader, desc=f"Ep {epoch:>3}", leave=False):
                sat    = batch["satellite"].to(device)
                uav    = batch["uav"].to(device)
                labels = batch["label"].to(device)
                optimizer.zero_grad()
                if scaler:
                    with torch.cuda.amp.autocast():
                        logits, _ = model((sat, uav))
                        loss      = loss_fn(logits, labels)
                    scaler.scale(loss).backward()
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    logits, _ = model((sat, uav))
                    loss      = loss_fn(logits, labels)
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                    optimizer.step()

            # Validation
            model.eval()
            val_loss = val_correct = val_total = 0
            with torch.no_grad():
                for batch in val_loader:
                    sat    = batch["satellite"].to(device)
                    uav    = batch["uav"].to(device)
                    labels = batch["label"].to(device)
                    logits, _ = model((sat, uav))
                    val_loss   += loss_fn(logits, labels).item()
                    val_correct += (logits.argmax(1) == labels).sum().item()
                    val_total   += labels.size(0)

            vl = val_loss / val_total
            scheduler.step(vl)

            if vl < best_val_loss:
                best_val_loss = vl
                no_improve    = 0
                model.save("best")
            else:
                no_improve += 1
                if no_improve >= patience:
                    print(f"    Early stop at epoch {epoch}")
                    break

    # ── Load best checkpoint ───────────────────────────────────────────────────
    best_path = os.path.join(run_dir, "best.pt")
    if os.path.exists(best_path):
        model.load(best_path)

    # ── Evaluate on held-out event tiles ONLY ─────────────────────────────────
    model.eval()
    all_preds:  list[int] = []
    all_labels: list[int] = []
    all_probs:  list      = []

    with torch.no_grad():
        for batch in test_loader:
            sat    = batch["satellite"].to(device)
            uav    = batch["uav"].to(device)
            labels = batch["label"].cpu().tolist()
            logits, _ = model((sat, uav))
            probs   = torch.softmax(logits, 1).cpu().numpy()
            indices = logits.argmax(1).cpu().tolist()
            all_preds.extend(indices)
            all_labels.extend(labels)
            all_probs.extend(probs)

    metrics = compute_metrics(all_preds, all_labels,
                              np.array(all_probs) if all_probs else None)
    print(f"    Held-out acc={metrics['accuracy']*100:.2f}%  "
          f"F1={metrics['f1']*100:.2f}%  "
          f"(n={len(all_labels)} tiles)")

    # Save per-round predictions
    pred_path = os.path.join(run_dir, "prediction.csv")
    with open(pred_path, "w") as f:
        f.writelines(f"{p}\n" for p in all_preds)

    return metrics


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════

def main() -> None:
    p = argparse.ArgumentParser(
        description="MultiSense Leave-One-Event-Out generalisation experiment",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--data_root",   required=True)
    p.add_argument("--output_dir",  default="./output/loeo")
    p.add_argument("--pairs_csv",   default=None)
    p.add_argument("--max_epochs",  type=int, default=300)
    p.add_argument("--seed",        type=int, default=42)
    p.add_argument("--device",      default="cuda" if torch.cuda.is_available()
                                            else "cpu")
    p.add_argument("--num_workers", type=int, default=2)
    p.add_argument("--eval_only",   action="store_true",
                   help="Skip training; load existing best.pt checkpoints.")
    args = p.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    all_results: dict[str, dict] = {}

    # Run all four LOEO rounds
    for held_out in HELD_OUT_EVENTS:
        metrics = run_loeo_round(
            held_out    = held_out,
            data_root   = args.data_root,
            output_dir  = args.output_dir,
            pairs_csv   = args.pairs_csv,
            device      = args.device,
            num_workers = args.num_workers,
            max_epochs  = args.max_epochs,
            seed        = args.seed,
            eval_only   = args.eval_only,
        )
        all_results[held_out] = {
            "accuracy": round(metrics["accuracy"] * 100, 2),
            "macro_f1": round(metrics["f1"]       * 100, 2),
        }

    # ── Print Table 11 ────────────────────────────────────────────────────────
    print(f"\n{'═'*60}")
    print("  Table 11 — Leave-One-Event-Out Generalisation Results")
    print(f"  {'Held-out Event':<25} {'Acc (%)':>9} {'Macro-F1 (%)':>13}")
    print(f"  {'─'*50}")

    acc_vals: list[float] = []
    f1_vals:  list[float] = []
    for held_out, res in all_results.items():
        print(f"  {held_out:<25} {res['accuracy']:>9.2f} {res['macro_f1']:>13.2f}")
        acc_vals.append(res["accuracy"])
        f1_vals.append(res["macro_f1"])

    mean_acc = sum(acc_vals) / len(acc_vals)
    mean_f1  = sum(f1_vals)  / len(f1_vals)
    print(f"  {'─'*50}")
    print(f"  {'LOEO Mean':<25} {mean_acc:>9.2f} {mean_f1:>13.2f}")
    print(f"  (Random baseline: {100/NUM_CLASSES:.1f}% — LOEO mean should be >> this)")
    print(f"{'═'*60}\n")

    # Add mean row to results dict
    all_results["LOEO Mean"] = {"accuracy": round(mean_acc, 2),
                                "macro_f1": round(mean_f1,  2)}

    # ── Save Table 11 as JSON and CSV ─────────────────────────────────────────
    json_path = os.path.join(args.output_dir, "loeo_results.json")
    with open(json_path, "w") as f:
        json.dump(all_results, f, indent=2)
    print(f"Results JSON → {json_path}")

    csv_path = os.path.join(args.output_dir, "loeo_results_table.csv")
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["held_out_event", "acc", "macro_f1"])
        writer.writeheader()
        for event, res in all_results.items():
            writer.writerow({"held_out_event": event,
                             "acc":      res["accuracy"],
                             "macro_f1": res["macro_f1"]})
    print(f"Results CSV  → {csv_path}")
    print("\n✓  LOEO evaluation complete.")


if __name__ == "__main__":
    main()
